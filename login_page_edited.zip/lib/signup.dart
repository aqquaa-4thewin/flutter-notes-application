import 'package:flutter/material.dart';
import 'package:flutter_application_2/profile.dart';

class signupPage extends StatefulWidget {
  const signupPage({super.key, required this.title});

  final String title;

  @override
  State<signupPage> createState() => _signupPage();
}

class _signupPage extends State<signupPage> {
  TextEditingController emailCont = TextEditingController();
  TextEditingController passwordCont = TextEditingController();
  TextEditingController nameCont = TextEditingController();
  TextEditingController ageCont = TextEditingController();
  final myFormKey = GlobalKey<FormState>();
  late String username;
  late String userage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(widget.title),
          centerTitle: true,
        ),
        body: Center(
          child: Container(
            decoration:
                const BoxDecoration(color: Color.fromARGB(255, 255, 252, 244)),
            child: Form(
                key: myFormKey,
                child: Padding(
                  padding: const EdgeInsets.all(50),
                  child: Column(
                    children: [
                      EnhancedTextFormField(
                          name: "email", controller: emailCont),
                      const SizedBox(
                        height: 10,
                      ),
                      EnhancedTextFormField(
                        name: "password",
                        controller: passwordCont,
                        isPassword: true,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      EnhancedTextFormField(
                          name: "full name", controller: nameCont),
                      const SizedBox(
                        height: 10,
                      ),
                      EnhancedTextFormField(name: "age", controller: ageCont),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          CustomButton(
                            label: "sign-up",
                            color: Theme.of(context).primaryColorDark,
                            onPressed: () {
                              if (myFormKey.currentState!.validate()) {
                                Navigator.of(context).push(
                                  MaterialPageRoute<void>(
                                    builder: (BuildContext context) =>
                                        profilePage(
                                      title: "profile",
                                      name: nameCont.text,
                                      age: ageCont.text,
                                    ),
                                  ),
                                );
                              } else {
                                print("not");
                              }
                            },
                          ),
                          CustomButton(
                              label: "login",
                              color: Theme.of(context).primaryColor,
                              onPressed: () {
                                Navigator.pop(context);
                              })
                        ],
                      )
                    ],
                  ),
                )),
          ),
        ));
  }
}

class EnhancedTextFormField extends StatefulWidget {
  final String name;
  final TextEditingController controller;
  final bool isPassword;

  const EnhancedTextFormField({
    super.key,
    required this.name,
    required this.controller,
    this.isPassword = false, // Default to false for non-password fields
  });

  @override
  EnhancedTextFormFieldState createState() => EnhancedTextFormFieldState();
}

class EnhancedTextFormFieldState extends State<EnhancedTextFormField> {
  bool isObscure = true;
  bool isvalid = false;
  bool isvisable = false; // if somthing has been written inside the text field

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      obscureText: widget.isPassword ? isObscure : false,
      controller: widget.controller,
      decoration: InputDecoration(
        labelText: widget.name,
        icon: (isvalid && isvisable)
            ? const Padding(
                padding: EdgeInsets.all(5),
                child: Icon(
                  Icons.check,
                  size: 20,
                  color: Colors.green,
                ),
              )
            : (isvisable)
                ? const Padding(
                    padding: EdgeInsets.all(5),
                    child: Icon(
                      Icons.close,
                      size: 20,
                      color: Colors.red,
                    ),
                  )
                : const Padding(
                    padding: EdgeInsets.all(5),
                  ),
        suffixIcon: widget.isPassword
            ? IconButton(
                icon: Icon(
                  isObscure ? Icons.visibility_off : Icons.visibility,
                  color: Theme.of(context).primaryColorDark,
                ),
                onPressed: () {
                  setState(() {
                    isObscure = !isObscure;
                  });
                },
              )
            : null,
        border: OutlineInputBorder(
          borderSide: BorderSide(
            color: Colors.blueAccent.shade700,
            strokeAlign: 100,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      onChanged: (value) {
        isvisable = true;
        if ((widget.isPassword && isPassword(value)) ||
            (widget.name == "email" && isEmail(value)) ||
            (widget.name == "full name" && isName(value)) ||
            (widget.name == "age" && isAge(value))) {
          isvalid = true;
        }
        setState(() {});
      },
      validator: (value) {
        if (value!.isEmpty) {
          return "Please enter your ${widget.name}";
        } else if ((widget.name == "email" && !isEmail(value)) ||
            (widget.name == "password" && !isPassword(value)) ||
            (widget.name == "age" && !isAge(value)) ||
            (widget.name == "full name" && !isName(value))) {
          if (widget.isPassword) {
            return "password must contain at least one small and capital letters, one digit, and one special character";
          }
          return "Please enter a valid ${widget.name}";
        } else {
          return null;
        }
      },
    );
  }

  bool isEmail(String em) {
    String p =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = RegExp(p);
    return regExp.hasMatch(em);
  }

  bool isPassword(String password) {
    if (password.length <= 8) {
      return false;
    }
    RegExp digitRegExp = RegExp(r'\d'); // checks for at least one digit
    RegExp specialCharRegExp = RegExp(
        r'[!@#$%^&*(),.?":{}|<>]'); // checks for at least one special character
    RegExp uppercaseRegExp =
        RegExp(r'[A-Z]'); // checks for at least one uppercase letter
    RegExp lowercaseRegExp =
        RegExp(r'[a-z]'); // checks for at least one lowercase letter

    if (!digitRegExp.hasMatch(password)) {
      return false;
    }
    if (!specialCharRegExp.hasMatch(password)) {
      return false;
    }
    if (!uppercaseRegExp.hasMatch(password)) {
      return false;
    }
    if (!lowercaseRegExp.hasMatch(password)) {
      return false;
    }

    return true;
  }

  bool isName(String name) {
    final validNamePattern = RegExp(r'^[a-zA-Z\s]+$');
    return name.isNotEmpty && validNamePattern.hasMatch(name);
  }

  bool isAge(String ageInput) {
    try {
      int age = int.parse(ageInput);
      return age >= 0 && age <= 120; // Valid age range: 0 to 120
    } catch (e) {
      return false; // If input can't be parsed into a number, it's not valid
    }
  }
}

class CustomButton extends StatelessWidget {
  final String label;
  final Color color;
  final Function onPressed;

  const CustomButton({
    super.key,
    required this.label,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      onPressed: () {
        onPressed();
      },
      child: Text(
        label,
        style: const TextStyle(fontSize: 16, color: Colors.white),
      ),
    );
  }
}
