import 'package:flutter/material.dart';
import 'package:flutter_application_2/models/task.dart';
import 'package:flutter_application_2/services/services.dart';
import 'package:flutter_application_2/widgets/custom-bnb.dart';
import 'package:flutter_application_2/theme/colors.dart' as colors;

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List tasks = [
    Task(
      categoryId: 1,
      createdDate: DateTime(2024, 9, 25),
      deadline: DateTime(2024, 9, 27),
      description:
          "Lorem Ipsum is simply dummy text of tIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsumhe printing and typese",
      id: 1,
      isChecked: false,
      name: "Task 1",
    ),
    Task(
      categoryId: 1,
      createdDate: DateTime.now(),
      deadline: DateTime.now(),
      description: "DEscription",
      id: 2,
      isChecked: false,
      name: "Task 2",
    ),
  ];
  List filterdTasks = [];
  bool fieldIsEmpty = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tasks App"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            flex: 1,
            child: Container(
              margin: const EdgeInsets.all(10),
              child: TextField(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Search",
                  hintText: "Enter Task Name",
                ),
                onChanged: (value) {
                  search(value);
                },
              ),
            ),
          ),
          Expanded(
            flex: 9,
            child: ListView.builder(
              itemCount: filterdTasks.isNotEmpty
                  ? filterdTasks.length
                  : fieldIsEmpty
                      ? tasks.length
                      : 0,
              itemBuilder: (context, index) {
                return taskCard(
                  filterdTasks.isNotEmpty
                      ? filterdTasks[index]
                      : fieldIsEmpty
                          ? tasks[index]
                          : null,
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: customBNB(),
    );
  }

  void search(value) {
    setState(() {
      if (value.toString().isEmpty) {
        fieldIsEmpty = true;
      } else {
        fieldIsEmpty = false;
      }
      filterdTasks = tasks
          .where((element) => element.name
              .toString()
              .toLowerCase()
              .contains(value.toString().toLowerCase()))
          .toList();
    });
  }

  Widget taskCard(Task task) {
    return Padding(
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 100),
        child: Card(
            clipBehavior: Clip.antiAlias,
            elevation: 25,
            color: colors.secondaryColor,
            margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                children: [
                  Row(
                    //mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Flexible(
                        child: Text(
                          task.name,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                      VerticalDivider(
                        color: colors.primaryColor,
                        width: 20,
                        thickness: 1,
                        indent: 20,
                        endIndent: 0,
                      ),
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.all(18.0),
                          child: Column(
                            children: [
                              Text(formattedDate(task.createdDate)),
                              Text(formattedDate(task.deadline)),
                            ],
                          ),
                        ),
                      ),
                      Flexible(
                        child: Text(
                          task.description,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(5),
                    alignment: Alignment.bottomRight,
                    child: Checkbox(
                      value: task.isChecked,
                      onChanged: (value) {
                        setState(() {
                          task.isChecked = value!;
                        });
                      },
                    ),
                  ),
                ],
              ),
            )));
  }
}
