import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrangeAccent),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'My First calculator in flutter'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  void _changeText(String newString) {
    setState(() {
      if (newString == "" && currentText.isNotEmpty) {
        currentText = currentText.substring(0, currentText.length - 1);
      } else {
        currentText = currentText + newString;
      }
    });
  }

  void reset() {
    num1 = "";
    num2 = "";
    op = "";
    result = 0;
    setState(() {});
  }

  TextEditingController mycontroller = TextEditingController();

  void addValue(String value) {
    if (int.tryParse(value) != null) {
      if (op == "") {
        num1 += value;
      } else {
        num2 += value;
      }
    } else if (value == '=') {
      calculate();
      setState(() {
        currentText = result.toString();
      });
      op = '=';
    } else if (value != "") {
      op = value;
    } else {
      if (op == '=') {
        op = "";
        num1 = num1.substring(0, num1.length - 1);
        num2 = num2.substring(0, num2.length - 1);
      } else if (num2.isNotEmpty) {
        num2 = "";
      } else if (op.isNotEmpty) {
        op = "";
      } else {
        num1 = "";
      }
    }
    setState(() {});
  }

  double calculate() {
    if (op == '+') {
      result = double.parse(num1) + double.parse(num2);
    } else if (op == '-') {
      result = double.parse(num1) - double.parse(num2);
    } else if (op == '*') {
      result = double.parse(num1) * double.parse(num2);
    } else {
      result = double.parse(num1) / double.parse(num2);
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            const Spacer(flex: 1),
            TextField(
              controller: mycontroller,
              decoration: const InputDecoration(
                  border: OutlineInputBorder(), hintText: 'Enter an equation'),
            ),
            const Spacer(flex: 1),
            TextButton(
                style: TextButton.styleFrom(
                    backgroundColor: Colors.deepOrange.shade50,
                    shape: const RoundedRectangleBorder(
                        side: BorderSide(
                            color: Color.fromARGB(255, 242, 148, 119),
                            strokeAlign: 5,
                            width: 2))),
                onPressed: () {
                  List<String> tokens =
                      mycontroller.text.split(RegExp(r'(\+|\-|\*|\/|\=)'));
                  List<String> operators = RegExp(r'(\+|\-|\*|\/|\=)')
                      .allMatches(mycontroller.text)
                      .map((e) => e.group(0)!)
                      .toList();
                  List<double> numbers =
                      tokens.map((e) => double.parse(e)).toList();
                  addValue(numbers[0].toString());
                  addValue(operators[0]);
                  addValue(numbers[1].toString());
                  print(operators);
                  if (operators[operators.length - 1] != '=') {
                    operators.add('=');
                  }
                  addValue(operators[1]);
                  setState(() {
                    mycontroller.text = result.toString();
                  });
                  reset();
                },
                child: const Text(
                  "calculate for text field",
                  style: TextStyle(fontSize: 20),
                )),
            const Spacer(flex: 1),
            Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 227, 189, 167),
                    borderRadius: BorderRadius.all(Radius.circular(10))),
                child: Text(
                  currentText,
                  style: Theme.of(context).textTheme.headlineMedium,
                )),

            // Text("num1 = $num1 num2= $num2 op= $op result= $result")
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        height: 350,
        child: Container(
          alignment: Alignment.bottomCenter,
          padding: const EdgeInsets.all(8),
          decoration: const BoxDecoration(
              color: Color.fromARGB(255, 227, 189, 167),
              borderRadius: BorderRadius.all(Radius.circular(10))),
          child: Wrap(
              spacing: 5,
              runSpacing: 10,
              // crossAxisCount: 5,
              // crossAxisSpacing: 6,
              // mainAxisSpacing: 5,
              children: [
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("-");
                    addValue("-");
                  },
                  tooltip: 'subtract',
                  child: const Text(
                    '-',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("+");
                    addValue("+");
                  },
                  tooltip: 'add',
                  child: const Text(
                    '+',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("/");
                    addValue("/");
                  },
                  tooltip: 'divide',
                  child: const Text(
                    '/',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("x");
                    addValue("*");
                  },
                  tooltip: 'multiply',
                  child: const Text(
                    'x',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("=");
                    addValue("=");
                  },
                  tooltip: 'equals',
                  child: const Text(
                    '=',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                    onPressed: () {
                      _changeText("");
                      addValue("");
                    },
                    tooltip: 'Back',
                    child: const Icon(Icons.backspace_outlined)),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText('1');
                    addValue("1");
                  },
                  tooltip: '1',
                  child: const Text(
                    '1',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("2");
                    addValue("2");
                  },
                  tooltip: '2',
                  child: const Text(
                    '2',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("3");
                    addValue("3");
                  },
                  tooltip: '3',
                  child: const Text(
                    '3',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("4");
                    addValue("4");
                  },
                  tooltip: '4',
                  child: const Text(
                    '4',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("5");
                    addValue("5");
                  },
                  tooltip: '5',
                  child: const Text(
                    '5',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("6");
                    addValue("6");
                  },
                  tooltip: '6',
                  child: const Text(
                    '6',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("7");
                    addValue("7");
                  },
                  tooltip: '7',
                  child: const Text(
                    '7',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("8");
                    addValue("8");
                  },
                  tooltip: '8',
                  child: const Text(
                    '8',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                FloatingActionButton.large(
                  onPressed: () {
                    _changeText("9");
                    addValue("9");
                  },
                  tooltip: '9',
                  child: const Text(
                    '9',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
              ]), // This trailing comma makes auto-formatting nicer for build methods
        ),
      ),
    );
  }

  String num1 = "";
  String num2 = "";
  String op = "";
  double result = 0.0;
  String currentText = "";
}
