import 'package:flutter/material.dart';

Color primaryColor = Colors.purple;
Color secondaryColor = Colors.purple.shade100;
