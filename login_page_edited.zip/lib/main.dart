import 'package:flutter/material.dart';
import 'package:flutter_application_2/profile.dart';
import 'package:flutter_application_2/signup.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'website',
      theme: ThemeData(
        colorScheme:
            ColorScheme.fromSeed(seedColor: Colors.blueAccent.shade700),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Login Profile '),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class EnhancedTextFormField extends StatefulWidget {
  final String name;
  final TextEditingController controller;
  final bool isPassword;

  const EnhancedTextFormField({
    super.key,
    required this.name,
    required this.controller,
    this.isPassword = false, // Default to false for non-password fields
  });

  @override
  EnhancedTextFormFieldState createState() => EnhancedTextFormFieldState();
}

class EnhancedTextFormFieldState extends State<EnhancedTextFormField> {
  bool isObscure = true;
  bool isvalid = false;
  bool isvisable = false;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      obscureText: widget.isPassword ? isObscure : false,
      controller: widget.controller,
      decoration: InputDecoration(
        labelText: widget.name,
        icon: (isvalid && isvisable)
            ? const Padding(
                padding: EdgeInsets.all(5),
                child: Icon(
                  Icons.check,
                  size: 20,
                  color: Colors.green,
                ),
              )
            : (isvisable)
                ? const Padding(
                    padding: EdgeInsets.all(5),
                    child: Icon(
                      Icons.close,
                      size: 20,
                      color: Colors.red,
                    ),
                  )
                : const Padding(
                    padding: EdgeInsets.all(5),
                  ),
        suffixIcon: widget.isPassword
            ? IconButton(
                icon: Icon(
                  isObscure ? Icons.visibility_off : Icons.visibility,
                  color: Theme.of(context).primaryColorDark,
                ),
                onPressed: () {
                  setState(() {
                    isObscure = !isObscure;
                  });
                },
              )
            : null,
        border: OutlineInputBorder(
          borderSide: BorderSide(
            color: Colors.blueAccent.shade700,
            strokeAlign: 100,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      onChanged: (value) {
        isvisable = true;
        if ((widget.isPassword && isPassword(value)) || isEmail(value)) {
          isvalid = true;
        }
        setState(() {});
      },
      validator: (value) {
        if (value!.isEmpty) {
          return "Please enter your ${widget.name}";
        } else if ((widget.name == "email" && !isEmail(value)) ||
            (widget.name == "password" && !isPassword(value))) {
          if (widget.isPassword) {
            return "password must contain at least one small and capital letter, one digit, and one special character";
          }
          return "Please enter a valid ${widget.name}";
        } else {
          return null;
        }
      },
    );
  }

  bool isEmail(String em) {
    String p =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = RegExp(p);
    return regExp.hasMatch(em);
  }

  bool isPassword(String password) {
    if (password.length <= 8) {
      return false;
    }
    RegExp digitRegExp = RegExp(r'\d'); // checks for at least one digit
    RegExp specialCharRegExp = RegExp(
        r'[!@#$%^&*(),.?":{}|<>]'); // checks for at least one special character
    RegExp uppercaseRegExp =
        RegExp(r'[A-Z]'); // checks for at least one uppercase letter
    RegExp lowercaseRegExp =
        RegExp(r'[a-z]'); // checks for at least one lowercase letter

    if (!digitRegExp.hasMatch(password)) {
      return false;
    }
    if (!specialCharRegExp.hasMatch(password)) {
      return false;
    }
    if (!uppercaseRegExp.hasMatch(password)) {
      return false;
    }
    if (!lowercaseRegExp.hasMatch(password)) {
      return false;
    }

    return true;
  }
}

class CustomButton extends StatelessWidget {
  final String label;
  final Color color;
  final Function onPressed;

  const CustomButton({
    super.key,
    required this.label,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      onPressed: () {
        onPressed();
      },
      child: Text(
        label,
        style: const TextStyle(fontSize: 16, color: Colors.white),
      ),
    );
  }
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController emailCont = TextEditingController();
  TextEditingController passwordCont = TextEditingController();
  final myFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(widget.title),
          centerTitle: true,
        ),
        body: Center(
          child: Container(
            decoration:
                const BoxDecoration(color: Color.fromARGB(255, 255, 252, 244)),
            child: Form(
                key: myFormKey,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      EnhancedTextFormField(
                          name: "email", controller: emailCont),
                      const SizedBox(
                        height: 10,
                      ),
                      EnhancedTextFormField(
                        name: "password",
                        controller: passwordCont,
                        isPassword: true,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          CustomButton(
                            label: "login",
                            color: Theme.of(context).primaryColorDark,
                            onPressed: () {
                              if (myFormKey.currentState!.validate()) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute<void>(
                                    builder: (BuildContext context) =>
                                        profilePage(
                                      title: "profile",
                                    ),
                                  ),
                                );
                              } else {
                                print("not");
                              }
                            },
                          ),
                          CustomButton(
                              label: "signup",
                              color: Theme.of(context).primaryColor,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute<void>(
                                    builder: (BuildContext context) =>
                                        const signupPage(title: "signup"),
                                  ),
                                );
                              })
                        ],
                      )
                    ],
                  ),
                )),
          ),
        ));
  }
}
