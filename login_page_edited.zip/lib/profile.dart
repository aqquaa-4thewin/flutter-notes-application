import 'package:flutter/material.dart';

class profilePage extends StatelessWidget {
  profilePage(
      {super.key,
      required this.title,
      this.name = "john doe",
      this.age = "30"});

  final String title;
  final String name;
  final String age;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(
            title.toUpperCase(),
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          elevation: 100,
          centerTitle: true,
          actions: const [
            Padding(
                padding: EdgeInsets.only(right: 50),
                child: Icon(
                  Icons.account_circle,
                )),
          ],
        ),
        body: Center(
          child: Container(
              color: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: ListView(children: [
                  Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        children: [
                          const CircleAvatar(
                              radius: 50,
                              backgroundImage: NetworkImage(
                                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSEhIVFRUVFRUVFRUVFRUVFRUVFRUXFhcWFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGjciHyUtLS0tLS0vLS0tLi0vOC0tLS0tLS0tLS0tLS0tLy0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQIDBQYEBwj/xABJEAACAQIEAwUDBgoJAgcAAAABAgADEQQSITEFQVEGEyJhcYGRoQcyQlKxwRQjU2JygpKi0fAkM0NjsrPC4fEVcxY0ZKO00+L/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAgMEAQX/xAArEQACAgEDAwMDBAMAAAAAAAAAAQIDEQQSITFBURMiMjNhcbHR4fAUI4H/2gAMAwEAAhEDEQA/APWxARAYsAWF4kWALAxLxYACESEAUmF4RIAsLxLxRACLEiwBYTLcY7dYXDUyzsSy1DSamurqQSLld7WsdL3BE8p7bfKTUxDAYd3ohQ6MFdrVFa2pWw1Gu9t9tJzJ3B7R/wCKsDqPwuj4TY/jF0ObJb9rT1I6y2VgRcG48p8hU6rEjLvrNVwLtZxHDEFKzMqhRkbxDJe5Guo339Iyd2n0neJPHuA/KVis475Q6/SW4BsTa69CNPI35bz0QcfFWkKuGs4IJF7bjTKfECpB0OhjJzDLuLK/geP76kHZcraq6nkw39ksJ04JaAhFgCQMWJAEiGOiEQBsbFiQBpjDJDI2EAiYSFxOgyJxOg5ikJLaJALQR0QRROAWLEiiAELwiQBYQhACESEAWEIQAEou1HaWjhUa9akKoXMKbsMxGn0Qb8xL4T5l+ULjL4jF1Pqq5tprbbfpa2m32zjOpFVxzHrWrPURQmYk5VJtvuOg8to3A4RD4qhAHU319AJx4S2YDfX+TNfwnsi+J8Ray7KPKQlJIthBy6FVVxVJR4VVgPVW+wSNuJruoOb4/wAJ6Dg/kyp21Zr+Wk7B8lVGxu58pXvRb6TPLK3Ec2qjKbadD/N5d8L7S1qKkU2tmKFri/ive4H1psR8mCi+Y36AaGZDtV2UOEKsNVJtz0PrOqazgi6njJ6f8nnaVqtRsPVQB2XvVYC2ba4I5EaTf3nhvye8SFLF0mqk5GBpgn6Bbr5ZrT3IS5MoksMIsSLadIhCEWAJEIjohgDLRCI8xpEAYZG0lMYYBEYxo9owwCMiJH2hALARbRBHCAIYsIsASEDFgCQixIAQhAwBIoiGF4Apnyj2q/8AOYkXv/SK1yObd42Yj23n1cDPlDtLQK47Eob3GJrA33NqrWJ9Rr7ZxnUdnZzs89UhzsRppuDzntHAsMFUADaYzszZUF7AAC95tOHcSo3C96l/UTHOTkz0oQUY8GioATqvOHD1lPMe+dDOBubTqINcjqszHa3horYeoltbEj1G0vMRxCiu9RR+sL+6cNfEq4OVgeWh6zjOxR4PiKhW3lv7Nx6ifRHYvGvXwOHq1PntSGY9WGhPttf2z597UKUqsByY6W5j+M+heyNILgcMo2FClb9gGaoGKzh4LeLAQkysWEIQAEDFhaAMiGPIjTAGGMMkIjGgETSMyVpC0AbaLEvCAWAjxIxH3gCwvEhAAwEDEEAWESLACEIkADCBiXgCz58+V7CU04qxT+0Wm9QD8oRY+hsFNvO/OfQYniXywcPVeIJUB+etNmHQi6X9oRZGT4JwWWViUGO5tTUC4va5kgXDVRZUrZuTLnNyOulvjNJ2cpJUSzqD6zS4bgVNdVZwOgy/aRf4zGmek4mM7P1a1GqiEPlLZbm9viNfXbzm47RI3djICSRsPfKrFovfKByPrr5k85pqmmW/SA+MHlVFE77NXpV2LarlDlN7eLKfD7RL/BqGtUoApY+JTfUe2x6zYvwmkxzC4v0OkkGHVBYQ0zmUeK9usGTjco0NQpa+g8QCm5n0Bw/DClSp012REQW6KoH3Tynj3ChiOIUFI0yktbpTJZb+V9PbPXEGg9BNNTyjFfHDyOiwhLSgWKIkIA6JCEAQwhCANaRPJTImgEbSJpK0iaANixDCAdoMfeRqY+AOhEEWALEhCAEIQgBEixIAGNMdG2gCieZfLTw0FaOIA1F0J62OdR/mT00Sv7Q8Kp4rDvSqLmBUldSCHCnKQRz1nJLKJQlh5PJ+zuOy5ehmqxHG1C2zW8/uE804Pj8op5hbLUAYHcA+Gx/nlOjtPRrNiXRNRYMmtgUNiLe249kx7ecHpKeUO4h2kqJVJSoWAa40HuvvLte3NVrXKrltm8Jc/EiVPZ3gVFmBrvUU3BKrTbqL/RI2+yafiHZjCHxCpXzMWvamtjawXwhfqjpqbSWEczLPP6FzS40gQVab51+kvMedpYrjxUUEbEaTzfivAMRSRqlNr0lANiuWodeVjsNNZofwjuKVKmT48pZv4e8yD4Ov7nXwg97xBhr4aar+3UBPwWejzzz5L6PeVMTiGW/iVFYnoDe3v3noc1VRwjDdPcwhCKJYUhCF4QBYQhAC8bHRCIAwxjR5kbQCNpE0laRmARwi2hAOpJIJChkl4A+KIy8UGAPiRIsAWIYQgBC8LxIAsQRYkAcIQEIB89/KPwpsHjXFiKVa1WmRtvqPUEfEQ4Vx8Oyipr4FS/QAk/fPQflqo06mFpISO973Mgv4soRg5/R8SA+onhtGqUax0tf/AG16SqUU+C+E5RSZ6WeLtSOmUjlf101E7cJ2weociAXNraFr+kw3DOLLe7anYA62uLD75b0uJKgLAAWC2tva/wDz75TtaNasT7mr7YcW7vD93e7VLZvIeyYfEcSd3IFyz2RANTrsAPdK/iPEmc+Jrm/XS03XyS8JRawxGIKqxUigrkAliR4hf6Vr2HnJxil1KJTbzg9K7JcH/BMLTom2YDM5HN21PrbQeyXF46NImgyBFBiWiwAiwgIACEWJACJAmNJgCNImj2MjYwBhkbR7GRsYA2ES8IBOhkoMgpyZYA8RRGiOEAdCAi2gCRYRDAFhEEIAsSKJDisXTpi9RwvqdT6DcwdSz0Jpz8R4hTw9J61ZstNBdjv5AAcyTYAcyZmOJ9tL5hhVVsnzqj3yjW1lA3Pt06Tz7tPxbE4jwVajMMtRguirmVCQcoAF7C3tMjvWcF0dNNx3Y4OTj3EauKxrVahOqWRfoomY2Ue65PMkzPcX4SSSRoZqalFWFOqpGa1yOeU6i/tJnQMKHEzOTzk2OuOMLoebHBVByvbpO/DcOrVLAK2vXbfzm6HCvKW2AwW067GVqlFH2b7HgHPUGY8r7Dz+yXXafhrN+D92NVrJtpoTaafCUABEq0g1ReiHOfWxAHxPwkMtvJbBJPCNHwPGmrTIb59Nij+zVW87gg+t5YzzThXEHFcvTJBZnH5pWykZgf0Rr6zWUuPlVzVEuALkruBzOU+znNe5dGYpaeeNyXBf2hOXBcRpVRem4a/nr7p1yRS011EhaEUCDgRIpjTAEMaxjjGNAGGMMcYwwBjGRtHNIiYAXhGXhAOlJKsiSSiAPEcI0RwgCxRGxYA6JaEixWIWmpd2Cqu5OwgEolZxDjtGlpmzN9VSND5nYTD9oO174iqmHoeCkx1c6Fha+xPPS3l15ceJoqpzOSbHQbADbQEC3LZT6yEm0aqKFN89jTYrtNUe4utMC5Nmubebb8xtlmI/D+8D1KlcNfMNzzAU6c7K77/VEtawpLRqsNPxbcxv7QOnWZqgtLub/wAOa1+R05LzHLWdgs8sla9ktsehdYAU0woOYEPV5fOIGhnHxo0gwqZrqjgPYf2bgBtevL2mdGEVEp4cDW5vtblflUv9nrI+PMi03XbOwW91NtWN7ZR06j1kNvvL1ZL/AB2V3Z2tl7xHW7KwUDW1mvvzNmVvhe+k0eDwoYBlsQehBGm+o3mNpM1maxAyim2XX5tRVcgAnZMwJ52Y63mt7KYod/TpIc9BgFC62F2sNb7ga+i2kbIpvghVPMcPqi+o4EEaiSU8HY6TU0+GJtb3H+MlThdMdffI+iyHroztWpkW/PYDqZnuLcTqUKR1LmsbAeRNiQR7rg72nb2zrEMrUELKhIKKLs9yLsp3zDly9L3mcfFmvWLWJpKpy2DBjYePbVallI23AuDJ1xWeSVyagl5LjgpQnMGACoTqdRf+IOYeREu6Vek2neLY3FjpvM3wMpUFZj9dQbAWtlJAHjAtqQPID0Fkq07en6H3Mv2mdnFbi6mUnXgpsFiEptVomrZkY2Iv9EM4OYfmhh+vNH2b7RvlZWro5pkA3N9Dpa/qDMriUprj6i/XKfV+lkTo3nzHpG9mcRSNVhb51INuN8qn8lb6UsceMoxeo21uPVcJxpG0OnmDmHw1lkrAi4IIOxGxnmlqWboeoJv9w+yWWF462FZM5L0XJRrbq24a3w8/PeRjJk7tOorMTcmIYlGqGAZSCCLgiOMmZBtoxo8yN4BG0Y0cTGEwCN5CxkrmQNAEixt4QDsEesjUx6wCUGKI1Y4GAOEdGiLeALPPflNxj1WXCUxdQve1eYuBdcw8ha3m4P0Z6CTPKMNj+9ariN/wjEhV/wC0jCw9m3vkZS2ltNTslhFFRoualBycqjICTpbwpTNhsPEr6C01vEsDSVHN2JGvlrqOmmsou0VG2cLoFLWHS/4xbe01j+rLvG1+8w9Jx/aCmD7WW/wMrsllJo9DS07bHGRNx+nSGGc5NygsDYb+nnM69Cj3Nu7I9Dt4aP8A9je6XfaVv6MB1f7Bf7pR4r5gHX7c9QfYKc7W3gjbVBzfBcYDCIj4cKCbU7+L0tsDI+1uEpCkz5Nnpki+mtwftndSX8fb6lMD3/8AEZ2pTNhKv6o9t/8AeVqT3F8qYqjGOyKBeEIcTTXO+WqtVUU2sjAk6WGt+u+gk3ZqouExSjEG1PUrVAOQsfri3gbqRv8AY3OXTDVAbMpDX6Fqrj/TNHSIDupAsSWAPnqV+MnOTRVRRCWUbmi1wGDXBAII1BB2MnzaSp4I1qSjkAQPQEj7pagS5PKPOsjtk4+Dzz8Irg1KAUh0/tDYnJfQr1mfxXC6q1mFJ+7NSmzVA1mzvfR/FqGIBBI3A1m67QMBVBGhym52NrzM4ty2LW/5NF138TNp+8JUsKWDd6blUpt9RnZHhqZawZ2Y51JIA/PE0C4Cja1m9b6/bKTsm+tUdQh+P/6l+pkLJPJo09MdhneLUKVPGK2S96avc/m3OnuEXgdGkmM7vu1Hzkvv80ld7fmR/ahPxuHbqCp9LqP4zlRyMTRf61j7XGY/GpLFJuJldMFng0QCFiDTUG1jYa77iUfaeg1PuhTOZc5dhzA22t/NucuqjfjyPK371pSYqt3mKNtVW1MeYAJYeegf22kK28mnVVpxSXBpOwOMIDUiCFJuvTOqjvFHtDn9UzYkzDDENRCtzRs7WFrnNmqG3mC/vm3DAi42OvslsZbjzb6nXJZ8CkyJjHExjSRQRsZExj2kbGARtInMkcyFjAEzQjLwgFgI8SBTJlMAlUx0jBjwYA4GF4ghAKXtrjjRwOIcfO7sov6VQhBb9q/snnhTukw1L6pUn1PiPxPwmm+VTEHucPRB1q4lL+a07sb+0rMrxPHk1aYqLa7Dxe2VWcnoaBqMm2WHGUBY9WUWHXKGY287Ar+ues5uE1gMNSVzc0sQyWG9hmYf6ZJx8kVMPbU2dhY7kWKj22A9so+Cplr1KbE6Opucpv4HUEZyL6Ih06zkY5hyWWWv1k4+f4LftHxake6Qh+bfHfbo05DjKZrU6dmJzrfb6CqG/eR5DxR0fEhDsFRNDSHzzk6H6490fwarTfF5/qq1T5yfSOflT/PaWqKUTHOc3J89zQ4fii99UYJdbhdfIf7yPj3FKXcMCGGaoB9h8+hkHDa6+I9WP0nB6bgZf3Zx9p6id0g61L70TspHMCVQismzUSkq+GQ4KvSBWnmtc08pO3zqh6C2pmi4lhajnwVEtax1IIOUAONDcjXTz3mQ4nSUNSYdfqN+Vr21Rj0E0uLoKrtqLE/lEHLoRf3iStimV6actzT8G04ER3CC98pKk+2/3iXhNhMr2WAFE5SCO+5MG3VRuPSaisdBJx6GW/6jMTxOm1Svn+iGIy665QbHz1+2U9VD+GAmw/qjr5Nf7pNUxVQM34wDxNbbr6TOcYVjiA7G/wCL3uirornQsR8JXCOZG6+1xqikvBd9nKtNK7ozi/dDbyCH7pdtxKiPrH+fSZDhVBVxpW48XerpmfZnG6C30RzmgAQf8U1/xFmnbIrJHTWSafJzdrOJUhTpuFY5XI94LdR0EqcRxlPxdqeqlQup3FSqo+l/dpLHj7IcOx18LKfnpzIHKn5GUrYlMtI66MP7T86k35P++MnBLBmtct7WTT4rjCZ3IUhgDl6ZhcjnttKWjVNIKxvfOt772uHY/uKPUPJcRVVu8tvZrXNIi+X0B904uIYmmtBc1TOwBGm5tke503Pfk7DeQhHwarp7cKXg12JGYsD9LQ/rAj75o+yOO73CUyfnKMjeq/7WmMq8VcscigCya/qjnLH5PeIN3teg31nZf1Hsfg6/szlaxkr1c98YvHY3RjGMVjI3lpgI2MiYyRpExgETyIyRpGYA2ELxIB0I8mVpxI86EaAdStJAZzK8lVoBLeLGXiiAeYfKbjD/ANQwlO2lNS52tdyeR02Vd+souPVVshtbY6eHn01X3WkvajGFuLO3JXCC+3hGT/T8Z39oMMlRAStjbcSmcj09HXJxeCn4nWcYqiQ3hXIuug10zDkfonQzn7M1RWxZD+EqmVt7kKfAdb8nPuEiwGJanWcNfKLNfcHIveeJTdT/AFYGo5x/ZVr4up4QMqBRYWBAyrtyPhMsk/Zkz0Qzcovz+5YPh6S4uoSW8FmH6g7zqPqTs7M4Wjeu1icqhR7Lr1lZxBv6TX/7b/8Ax6k7uz9T8XXPV7e8yLk9pbGmPqJfcvuHYejkF066385Xdp8DR/ELdgCzf4rdfOd+BfwicPaVvHhx0N/eySuEnuNeqphtX5KzinClbu8tTkh19reX15pq+Bqk6OCCq/SP1RM7i6n9T+jS/wAql/GaiubH3fECSskyjTULe8PsXXZegyUnDG57xSNSeQ/hNHXOqjzmc7MvdX/SX7DL6o93UeV5ZB5iZNVHba0eeVcRUzNo+7fSqbX9bSg4rhaz1lIG65bnU63GpNzzmo/CCC2o3PIfDSU3G6l6tC56f4l5SuE/cbdRS9i57o5hw9vwum7VBq453+fZuZH5Saf/AKVTUm7E+kyXEqpHdsDrakf/AGKX8JrDWNzr0+Kgj7YskzmlpW5rJHxHh1E0Kosx8N/2b/nTP0cJRKU7Kf6xRufpNSHX+6mkD38J2bwsOoJF/SY/E4koKuWwCOcmlyCpupvz1Y/yJ2uTawNRRCM8vuXPEOG0rPlLAkPvtqpt1mXaigw97g68td1oj5xAX+zG2abCpUYrqTfLr626cpk6WAQYe71Mxumi6/Rqc7/mdZ2mXXJzXVJOO1dS+o41TqADdVsbBjt1cH7IvB+Jd1xAMdAcQiHRdq6lPqjmQfZF7POoogqoFyLX1NgAJycWxJWtXawund1BoN1C2+MQl7mVW1S9OB7I0jMeHBAYbEAj0OsY8sMBC8hJkrSEwCN5GTHuZEYAhixl4QCNGkyPFhAJleTI0IQCVWjw0IQDwbjFW+MrP/6s/wCNpq8Uc1Jfd9kITPZ2Pc0HRmR762IqgdCBfmCjL79ROvsr48VXYADRD5eIuYQk38TNB4s3dyTiaf0qoMw1ot150HHTzkvAyMlUZhrWHI9LwhDXtM8LZeqvyaDCAZfnDfoZw9oUJrUwCDlRTz5eo8oQkK1yaNVfP2nHjcMwqU1I0BpjcbBKS/6TLTinfFh3ZFgQGBJFxlsDp0hCLS3RPe3nwanshTIptc3NwpPUqoufjLuk96p8haEJdX8UYdX9aR59UW7AjQhiDbc7X19CT7BKvjrnPQv5/BlhCUQ+R6up+mv+HFxB7pTH5lL/ACkmsrUyCvi3VRtfUD1hCSs6FOmf+zH2GoWzhSdeR62mVwdHvGdSfnVxfnoWckfuCEIr6Mlq/nH8GixNGysS2uUk78h6TKo5/B25Wtt5LXP+oQhEOhG6bk1kvuDLlw9Ifmg+/wD5nFxU3rYgdUT7L/dCEQ+TJaj4R/vY9Z7P1s+Ew7daNO/rkF52NCEvPFZzuZETCEHCJpE0WEAhLRIQgH//2Q==",
                              )),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            " $name \n $age years old",
                            style: TextStyle(fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(
                            height: 40,
                          ),
                          const Text(
                            " Photos",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Card(
                              child: Padding(
                                  padding: EdgeInsets.all(10),
                                  child: GridView.count(
                                    shrinkWrap:
                                        true, // because grideview and list view are both scrollable
                                    crossAxisCount: 4,
                                    mainAxisSpacing: 10,
                                    crossAxisSpacing: 8,
                                    children: [
                                      Image.network(
                                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSACh7BHy3KIjQlJQkxMx55mjxIW5tEKIeRMQ&s"),
                                      Image.network(
                                          "https://images.unsplash.com/photo-1480455624313-e29b44bbfde1?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Z3V5fGVufDB8fDB8fHww"),
                                      Image.network(
                                          "https://www.shutterstock.com/image-photo/photo-handsome-happy-young-caucasian-260nw-1115156849.jpg"),
                                      Image.network(
                                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTN6Z5fsxwmKCixCZiS1rkUE55tBKpjBBMpyA&s"),
                                      Image.network(
                                          "https://images.unsplash.com/photo-1480455624313-e29b44bbfde1?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Z3V5fGVufDB8fDB8fHww"),
                                      Image.network(
                                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSACh7BHy3KIjQlJQkxMx55mjxIW5tEKIeRMQ&s"),
                                      Container(
                                        decoration: const BoxDecoration(
                                            color: Colors.blueAccent,
                                            borderRadius: BorderRadius.all(
                                                Radius.elliptical(4, 6))),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                            color: Colors.blueAccent.shade100,
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.elliptical(4, 6))),
                                      )
                                    ],
                                  )))
                        ],
                      ))
                ]),
              )),
        ));
  }
}
